﻿/*******************************************************
 * Copyright (C) Dennis Dietrich                       *
 * Released under the Microsoft Public License (Ms-PL) *
 * http://www.opensource.org/licenses/ms-pl.html       *
 *******************************************************/

namespace PrimaryTestSuite.Support
{
    public enum DispatchMode
    {
        Post,
        Send
    }
}